package com.example.inicio_sesion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private Button btnLogin;
    private Connection connection;
    private int UsuarioId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //COLOCAR TEXTO DENTRO
        etUsername = findViewById(R.id.etUsername);
        etUsername.setHint("USUARIO");
        etPassword = findViewById(R.id.etPassword);
        etPassword.setHint("CONTRASEÑA");
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String USUARIO = etUsername.getText().toString();
                String CONTRASEÑA = etPassword.getText().toString();
                loginUser(USUARIO, CONTRASEÑA);
            }
        });
    }

    private void loginUser(String USUARIO, String CONTRASEÑA) {
        connection = SQLServerConnection.connectionclass();
        try {
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM USUARIOS WHERE USUARIO ='" + USUARIO + "' AND CONTRASEÑA ='" + CONTRASEÑA + "'";
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                UsuarioId = resultSet.getInt("ID_US");
                String insertQuery = "INSERT INTO RegistrosIniciosSesion (UsuarioId, FechaHora, Accion) VALUES (" + UsuarioId + ", CURRENT_TIMESTAMP, 'Inicio de sesión')";
                int rowsAffected = statement.executeUpdate(insertQuery);

                if (rowsAffected > 0) {
                    Toast.makeText(MainActivity.this, "Inicio de sesión registrado", Toast.LENGTH_SHORT).show();
                }
                Toast.makeText(MainActivity.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, PrincipalActivity.class);
                intent.putExtra("UsuarioId", UsuarioId);
                startActivity(intent);
                finish();

            } else {
                Toast.makeText(MainActivity.this, "Inicio de sesión fallido", Toast.LENGTH_SHORT).show();
            }

            resultSet.close();
            statement.close();
            connection.close();
        }  catch (SQLException e) {
            Log.e("ERROR", e.getMessage());
        }

    }

}
