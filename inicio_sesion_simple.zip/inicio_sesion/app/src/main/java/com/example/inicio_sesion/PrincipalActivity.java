package com.example.inicio_sesion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class PrincipalActivity extends AppCompatActivity {
    private Button btncerrar;
    private Connection connection;
    private int UsuarioId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        btncerrar = findViewById(R.id.btncerrar);
        UsuarioId = getIntent().getIntExtra("UsuarioId", 0);
        btncerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutUser();

            }
        });
    }
    private void logoutUser() {
        // Lógica para cerrar la sesión del usuario
        // Esto puede incluir la eliminación de datos de sesión, redirección a la pantalla de inicio de sesión, etc.
        connection = SQLServerConnection.connectionclass();
        try {
            Statement statement = connection.createStatement();

            String insertQuery = "INSERT INTO RegistrosIniciosSesion (UsuarioId, FechaHora, Accion) VALUES (" + UsuarioId + ", CURRENT_TIMESTAMP, 'Cierre de sesión')";
            int rowsAffected = statement.executeUpdate(insertQuery);

            if (rowsAffected > 0) {
                Toast.makeText(PrincipalActivity.this, "Cierre de sesión registrado", Toast.LENGTH_SHORT).show();
            }

            statement.close();
            connection.close();
        } catch (SQLException e) {
            Log.e("ERROR", e.getMessage());
        }

        Toast.makeText(this, "Cerrando sesión", Toast.LENGTH_SHORT).show();
        // Ejemplo de redirección a la pantalla de inicio de sesión
        Intent intent = new Intent(PrincipalActivity.this, MainActivity.class);
        intent.putExtra("UsuarioId", UsuarioId);
        startActivity(intent);
        finish();
    }

}