package com.example.notas;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private EditText et1,et2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);

    }
    public void abrircalendario(View view){
        Calendar cal= Calendar.getInstance();
        int año=cal.get(Calendar.YEAR);
        int mes=cal.get(Calendar.MONTH);
        int dia=cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dpd = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayofmonth) {
                String fecha = dayofmonth + "/" + (month+1) + "/" + year;
                et1.setText(fecha);

            }
        }, año, mes, dia);
        dpd.show();
    }
    public void grabar(View v){
        String nomarchivo=et1.getText().toString();
        nomarchivo=nomarchivo.replace('/', '-');

        try{
            OutputStreamWriter archivo = new OutputStreamWriter(openFileOutput(
                    nomarchivo, Activity.MODE_PRIVATE));
            archivo.write(et2.getText().toString());
            archivo.flush();
            archivo.close();


        } catch (IOException e){
        }
        Toast t = Toast.makeText(this, "Los datos fueron grabados", Toast.LENGTH_SHORT);
        t.show();
        et1.setText("");
        et2.setText("");
    }
    public  void recuperar(View v){
        String nomarchivo=et1.getText().toString();
        nomarchivo=nomarchivo.replace('/', '-');
        boolean enco=false;
        String[] archivos = fileList();
        for (int f = 0; f < archivos.length; f++)
            if (nomarchivo.equals(archivos[f]))
                enco= true;
        if(enco==true){
            try {
                InputStreamReader archivo = new InputStreamReader(
                        openFileInput(nomarchivo));
                BufferedReader br = new BufferedReader(archivo);
                String linea = br.readLine();
                String todo = "";
                while (linea != null){
                    todo = todo + linea + "\n";
                    linea = br.readLine();
                }
                br.close();
                archivo.close();
                et2.setText(todo);
            }catch (IOException e){
            }
        }else
        {
            Toast.makeText(this, "No hay datos guardados para dicha fecha", Toast.LENGTH_SHORT).show();
            et2.setText("");
            et1.setText("");
        }
    }
}
